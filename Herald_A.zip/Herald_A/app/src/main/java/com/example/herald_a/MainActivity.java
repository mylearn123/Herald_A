package com.example.herald_a;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.example.herald_a.Authenication.Login;
import com.example.herald_a.Authenication.Register;
import com.example.herald_a.MainCalendar.CalendarApplication;
import com.example.herald_a.Notes.AddNote;
import com.example.herald_a.Notes.EditNote;
import com.example.herald_a.Notes.NoteDetails;
import com.example.herald_a.Model.Adapter;
import com.example.herald_a.Model.Note;
import com.example.herald_a.Notes.Splash;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//second step i create a note_view.xml and make package name MODEL then i create class adapter

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    ActionBarDrawerToggle actionBarDrawerToggle;
    Adapter adapter;
    RecyclerView noteLists;
    FirebaseFirestore fstore;//for retrieve from firebase F.1
    FirestoreRecyclerAdapter<Note,NoteViewHolder> noteadapter;
    FirebaseAuth firebaseAuth;
    FirebaseUser user;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        fstore=FirebaseFirestore.getInstance();//for create firebasefirestore
        firebaseAuth=FirebaseAuth.getInstance();//for logout
        user=firebaseAuth.getCurrentUser();//for logout
//        Query query=fstore.collection("notes").orderBy("title",Query.Direction.DESCENDING);
        //for specific user id, data then go to edit note  which we implements the firebase query
        Query query=fstore.collection("notes").document(user.getUid()).collection("notes").orderBy("title",Query.Direction.DESCENDING);

        FirestoreRecyclerOptions<Note> dataStoreAllNotes=new FirestoreRecyclerOptions.Builder<Note>().setQuery(query,Note.class).build();

noteadapter=new FirestoreRecyclerAdapter<Note, NoteViewHolder>(dataStoreAllNotes) {
    @Override
    protected void onBindViewHolder(@NonNull NoteViewHolder noteViewHolder, final int i, @NonNull final Note note) {
        //this for the recieve the data from onCreate main Activity then assign to the note_view_layout..bind
        //after onCLick call the class Adapter in mainActivity
        noteViewHolder.noteTitle.setText(note.getTitle());//2.1 extract from the list then assign to the note_view_layout of...1
        noteViewHolder.noteContent.setText(note.getContent());
//        holder.mcardView.setCardBackgroundColor(holder.view.getResources().getColor(getRandomColor(),null));//create the method getRandomCOlor and bind with color
        final int code=getRandomColor();
        noteViewHolder.mcardView.setCardBackgroundColor(noteViewHolder.view.getResources().getColor(code));
        final String docId=noteadapter.getSnapshots().getSnapshot(i).getId();
        noteViewHolder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(v.getContext(), "the item is clicked", Toast.LENGTH_SHORT).show();//v.getContext is current View v
                Intent intent=new Intent(v.getContext(), NoteDetails.class);


                intent.putExtra("title",note.getTitle());//titles ko namema if click RecycleView then titleko positon 0 ma vako gayera basyo
                // add the data then pass to the NoteDetails...add Note datako lagi
                intent.putExtra("content",note.getContent());//contents ko namema if click RecycleView then contentko positon 0 ma vako gayera basyo
                intent.putExtra("code",code);//name given the next to the NoteDetails for receive color

                intent.putExtra("noteId",docId);
                v.getContext().startActivity(intent);
            }
        });
//        for meny icon popup from note_view_layout

        ImageView menuicon=noteViewHolder.view.findViewById(R.id.menuIcon);

        menuicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
               final String docId=noteadapter.getSnapshots().getSnapshot(i).getId();//for pop up
                Toast.makeText(MainActivity.this, "pop up clicked", Toast.LENGTH_SHORT).show();
                PopupMenu menu=new PopupMenu(v.getContext(),v);
//                menu.setGravity(Gravity.END);
                menu.getMenu().add("Edit").setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        Toast.makeText(MainActivity.this, "menu clicked edit", Toast.LENGTH_SHORT).show();
                        Intent i=new Intent(v.getContext(), EditNote.class);
                        i.putExtra("title",note.getTitle());//for edit,title is the name which is pass the data.getStringExtra("titile") to the EditNOte.class
                        i.putExtra("content",note.getContent());
                        i.putExtra("noteId",docId);//for pop up
                        startActivity(i);
                        return false;
                    }
                });
                menu.getMenu().add("Delete").setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
//                        Toast.makeText(MainActivity.this, "Delete click", Toast.LENGTH_SHORT).show();
                        DocumentReference docRef=fstore.collection("notes").document(docId);//reference to delete by help of docID
                        docRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(MainActivity.this, "delete sucessfully", Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(MainActivity.this, "Delete is unSucessfully", Toast.LENGTH_SHORT).show();
                            }
                        });
                        return false;
                    }
                });
                menu.show();

            }
        });
    }


    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.note_view_layout, parent, false);
        return new NoteViewHolder(view);//constructor of NoteViewHolder
    }
};

//side barko lagi
        drawerLayout=findViewById(R.id.drawer);
        navigationView=findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);//after 1st boolean onNavigationItemSelected....2
        noteLists=findViewById(R.id.noteList);


        actionBarDrawerToggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);//1
        drawerLayout.addDrawerListener(actionBarDrawerToggle);//1
        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);//1
        actionBarDrawerToggle.syncState();//1 to check
//      OLD
//        List<String> title=new ArrayList<>();//3
//        List<String> content=new ArrayList<>();
//
//        title.add("first");
//        content.add("content first");
//
//        title.add("second");
//        content.add("content second");
//
//        title.add("third");
//        content.add("content third");
//
//        title.add("four");//3
//        content.add("content fourth");

//        adapter=new Adapter(title,content);//3 old
//        noteLists.setLayoutManager(new LinearLayoutManager(this));// position in vertical
        noteLists.setLayoutManager(new StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL));//3 position milauxa content sanga
        noteLists.setAdapter(noteadapter);//3

        FloatingActionButton fab = findViewById(R.id.addNoteFloat);//for save floating button
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(view.getContext(), AddNote.class));
            }
        });



    }

    private int getRandomColor() {
        List<Integer> colorcode = new ArrayList<>();
        colorcode.add(R.color.blue);
        colorcode.add(R.color.skyblue);
        colorcode.add(R.color.lightPurple);
        colorcode.add(R.color.design_default_color_surface);
        colorcode.add(R.color.gray);
        colorcode.add(R.color.yellow);
        colorcode.add(R.color.red);
        colorcode.add(R.color.pink);
        colorcode.add(R.color.notgreen);
        colorcode.add(R.color.lightGreen);
        colorcode.add(R.color.greenlight);
        colorcode.add(R.color.colorPrimaryDark);
        colorcode.add(R.color.colorAccent);
        colorcode.add(R.color.colorPrimary);

        Random randomColor=new Random();
        int number=randomColor.nextInt(colorcode.size());
        return colorcode.get(number);

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {//2 for setting
        drawerLayout.closeDrawer(GravityCompat.START);// to no show the nav bar
        switch (item.getItemId()){
            case R.id.sync:
                if (user.isAnonymous()){
//                    startActivity(new Intent(this,Register.class));
                    startActivity(new Intent(this, Login.class));

                }else {
                    Toast.makeText(this, "You are connected", Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.addNote:
                startActivity(new Intent(this,AddNote.class));
                break;
            case R.id.logout:
                checkuser();// to check by on anymolouse user
                break;
            case R.id.notes:
                startActivity(new Intent(this, CalendarApplication.class));
//                Toast.makeText(this, "Comingsss soon", Toast.LENGTH_SHORT).show();
                break;
            case R.id.showUserSponsor:
                startActivity(new Intent(this,JsonDataUserlist.class));
                break;

            default:
                Toast.makeText(this, "Coming soon", Toast.LENGTH_SHORT).show();
        }
        return false;
    }

    private void checkuser() {
        if (user.isAnonymous()){
            displayAlert();
        }
        else {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(getApplicationContext(), Splash.class));
            finish();
        }
    }

    private void displayAlert() {
        AlertDialog.Builder warning=new AlertDialog.Builder(this).
                setTitle("Are You Sure").
                setMessage("after logout all notes will be delete , Be carefully").
                setPositiveButton("Sync Note", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(getApplicationContext(), Register.class));
                        finish();

                    }
                }).setNegativeButton("logout", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {


                user.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        startActivity(new Intent(getApplicationContext(),Splash.class));
                        finish();

                    }
                });

            }
        }) ;

        warning.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater=getMenuInflater();
//        inflater.inflate(R.menu.option_menu);
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.option_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==R.id.settings){
            Toast.makeText(this, "you click the setting bar", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    public class NoteViewHolder extends RecyclerView.ViewHolder{
        View view;//for any click on the view they saw the click listener
        TextView noteTitle, noteContent;
        CardView mcardView;//3

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            noteTitle = itemView.findViewById(R.id.titles);//itemview achieve data of inflator from viewHolder oncreateViewHolder(){...R.layout.note_view_layout)
            noteContent = itemView.findViewById(R.id.content);
            mcardView = itemView.findViewById(R.id.noteCard);//to set the random color in the content
            view = itemView;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        noteadapter.startListening();//updating the data in start activity
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (noteadapter!=null){
            noteadapter.stopListening();
        }
    }
}
