package com.example.herald_a.MainCalendar;

import android.app.Application;

public class App extends Application {
}
