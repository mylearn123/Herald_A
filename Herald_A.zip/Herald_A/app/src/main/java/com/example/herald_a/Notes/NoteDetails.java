package com.example.herald_a.Notes;

import android.content.Intent;
import android.os.Bundle;

import com.example.herald_a.Notes.EditNote;
import com.example.herald_a.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.text.method.ScrollingMovementMethod;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class NoteDetails extends AppCompatActivity {
    Intent data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_details);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);//for back button and  onOptionItemSelected
         data=getIntent();//data taneko....add Note datako lagi



        TextView title=findViewById(R.id.noteDetailsTitle);//for scroll...add Note datako lagi

        TextView content=findViewById(R.id.noteDetailsContent);//for scroll...add Note datako lagi
        content.setMovementMethod(new ScrollingMovementMethod());//enable hunxa scroll the content...add Note datako lagi

        content.setText(data.getStringExtra("content"));//add Note datako lagi
        content.setText(data.getStringExtra("title"));//add Note datako lagi
//        content.setBackgroundColor(data.getIntExtra("code",0));//random colorko lagi taneko color content.setBgColor("code",0)
//        OR
        content.setBackgroundColor(getResources().getColor(data.getIntExtra("code",0)));

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)

//                        .setAction("Action", null).show();
                Intent i=new Intent(view.getContext(), EditNote.class);
                i.putExtra("title",data.getStringExtra("title"));//for edit,title is the name which is pass the data.getStringExtra("titile") to the EditNOte.class
                i.putExtra("content",data.getStringExtra("content"));
                i.putExtra("noteId",data.getStringExtra("noteId"));
                startActivity(i);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==android.R.id.home){//its default home
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}
