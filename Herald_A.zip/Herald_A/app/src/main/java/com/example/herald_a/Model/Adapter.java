package com.example.herald_a.Model;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.herald_a.Notes.NoteDetails;
import com.example.herald_a.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//after we create class Adapter i extends RecyclerView.Adapter<Adapter.viewHolder...then create the class viewholder
//after that i again viewHolder extends RecyclerView.ViewHolder then implements matching constructor
//then we implement on Adapter class onCreateViewHolder,onBindViewHolder,getItemCOunt
public class Adapter extends RecyclerView.Adapter<Adapter.viewHolder> {//1..1.1
    List<String> titles;
    List<String> content;

    public Adapter(List<String> title, List<String> content) {
        this.titles = title;
        this.content = content;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {//1
        //view which we display the data for the recycleview
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.note_view_layout, parent, false);


        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, final int position) {
        //this for the recieve the data from onCreate main Activity then assign to the note_view_layout..bind
        //after onCLick call the class Adapter in mainActivity
        holder.noteTitle.setText(titles.get(position));//2.1 extract from the list then assign to the note_view_layout of...1
        holder.noteContent.setText(content.get(position));
//        holder.mcardView.setCardBackgroundColor(holder.view.getResources().getColor(getRandomColor(),null));//create the method getRandomCOlor and bind with color
        final int code=getRandomColor();
        holder.mcardView.setCardBackgroundColor(holder.view.getResources().getColor(code));
        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(v.getContext(), "the item is clicked", Toast.LENGTH_SHORT).show();//v.getContext is current View v
                Intent intent=new Intent(v.getContext(), NoteDetails.class);


                intent.putExtra("title",titles.get(position));//titles ko namema if click RecycleView then titleko positon 0 ma vako gayera basyo
                // add the data then pass to the NoteDetails...add Note datako lagi
                intent.putExtra("content",content.get(position));//contents ko namema if click RecycleView then contentko positon 0 ma vako gayera basyo
                intent.putExtra("code",code);//name given the next to the NoteDetails for receive color
                v.getContext().startActivity(intent);
            }
        });

    }

    private int getRandomColor() {
        List<Integer> colorcode = new ArrayList<>();
        colorcode.add(R.color.blue);
        colorcode.add(R.color.skyblue);
        colorcode.add(R.color.lightPurple);
        colorcode.add(R.color.design_default_color_surface);
        colorcode.add(R.color.gray);
        colorcode.add(R.color.yellow);
        colorcode.add(R.color.red);
        colorcode.add(R.color.pink);
        colorcode.add(R.color.notgreen);
        colorcode.add(R.color.lightGreen);
        colorcode.add(R.color.greenlight);
        colorcode.add(R.color.colorPrimaryDark);
        colorcode.add(R.color.colorAccent);
        colorcode.add(R.color.colorPrimary);

        Random randomColor=new Random();
        int number=randomColor.nextInt(colorcode.size());
        return colorcode.get(number);

    }

    @Override
    public int getItemCount() {
        //return the size of the array of another activity
        //after create adapter constructor
        return titles.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {//2
        View view;//for any click on the view they saw the click listener
        TextView noteTitle, noteContent;
        CardView mcardView;//3

        public viewHolder(@NonNull View itemView) {

            super(itemView);
            noteTitle = itemView.findViewById(R.id.titles);//itemview achieve data of inflator from viewHolder oncreateViewHolder(){...R.layout.note_view_layout)
            noteContent = itemView.findViewById(R.id.content);
            mcardView = itemView.findViewById(R.id.noteCard);//to set the random color in the content
            view = itemView;
        }
    }
}
