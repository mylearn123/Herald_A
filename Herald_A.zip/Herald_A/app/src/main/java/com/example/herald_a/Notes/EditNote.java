package com.example.herald_a.Notes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.herald_a.MainActivity;
import com.example.herald_a.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class EditNote extends AppCompatActivity {
    FirebaseFirestore fstore;//for create firebase
    FirebaseUser user;

    Intent data;
    EditText editNote,editContent;
    ProgressBar spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        editNote=findViewById(R.id.editNoteTitle);
        editContent=findViewById(R.id.editNoteContent);
        spinner=findViewById(R.id.progressBar2);
        data=getIntent();
        fstore=FirebaseFirestore.getInstance();//for create firebasefirestore
        user= FirebaseAuth.getInstance().getCurrentUser();


        String noteTitle=data.getStringExtra("title");//get the data from NoteDetail activity
        String noteContent=data.getStringExtra("content");

        editContent.setText(noteContent);//set for to edit the text
        editNote.setText(noteTitle);
        FloatingActionButton fab = findViewById(R.id.saveEditedNote);
        fab.setOnClickListener(new View.OnClickListener() {
//            to make the edit text..first we have to
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)

//                        .setAction("Action", null).show();
                String nTitle = editNote.getText().toString();
                String nContent = editContent.getText().toString();

                if (nTitle.isEmpty() || nContent.isEmpty()) {
                    Toast.makeText(EditNote.this, "Can not Save note with Empty Field.", Toast.LENGTH_SHORT).show();
                    return;
                }
                spinner.setVisibility(View.VISIBLE);
                //save garni kaam garxa below
//                DocumentReference dReference = fstore.collection("notes").document(data.getStringExtra("noteId"));//firestore create and recieve the id from main activity to Notedetails to here
                // for this we create firebase user and give         user= FirebaseAuth.getInstance().getCurrentUser(); then got to addNote and do same things
                DocumentReference dReference = fstore.collection("notes").document(user.getUid()).collection("notes").document(data.getStringExtra("noteId"));//firestore create and recieve the id from main activity to Notedetails to here

//                Map<String,Object> note = new HashMap<>();
                Map<String, Object> note = new HashMap<>();
                note.put("title", nTitle);
                note.put("content", nContent);
//                dReference.set(note).addOnSuccessListener(new OnSuccessListener<Void>() {

                dReference.update(note).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(EditNote.this, "Note edit sucessfully.", Toast.LENGTH_SHORT).show();
//                        onBackPressed();
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(EditNote.this, " tenson vayo tei pani feri try gara solti estai ho.", Toast.LENGTH_SHORT).show();
                        spinner.setVisibility(View.VISIBLE);

                    }
                });
            }

        });


    }
}
